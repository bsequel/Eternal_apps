# from django.db.models.signals import pre_save
# from django.dispatch import receiver
# from . models import *
# @receiver(pre_save, sender=CAMSSummary)
# def set_summary_entry_hash(sender, instance, **kwargs):
#     instance.entry_hash = instance.generate_hash()

# @receiver(pre_save, sender=CAMSTransaction)
# def set_transaction_entry_hash(sender, instance, **kwargs):
#     instance.entry_hash = instance.generate_hash()
